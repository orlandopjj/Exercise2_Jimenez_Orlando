package exercise2;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
//import org.testng.annotations.Test;
import org.junit.Test;
import org.testng.annotations.BeforeMethod;



//import selenium.ClsBrowser;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class Test1 extends ClsBrowser{


	SignInPage signInPage;
	
	
	@Before
	public void setUp() throws Exception {
		signInPage = new SignInPage();
		ClsBrowser.BrowserName = "Chrome";
		OpenBrowser();
	}


	@Test
	public void test() throws InterruptedException {
		NavigateToUrl("https://www.amazon.com.mx/");
		signInPage.SignIn();
		
	}
	
	@After
	public void tearDown(){
		CloseBrowser();
	}

}

