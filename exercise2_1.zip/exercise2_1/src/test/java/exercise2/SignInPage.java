package exercise2;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class SignInPage extends ClsBrowser{

	//Locators
	static By registerIdentifier = By.xpath("//*[@id=\'nav-signin-tooltip\']/a/span");
	static By userlocator = By.id("ap_email");
	static By continueBtn = By.id("continue");
	static By passwordLocator = By.id("ap_password");
	static By signInBtn = By.id("signInSubmit");
	static By promotionBtn = By.xpath("//a[contains(text(),'Promociones')]");
	static By loBtn = By.xpath("//span[contains(text(),'Oferta rel�mpago')]");
	static String titleProducts = ("//div[ @class='DealContent-module__truncate_sWbxETx42ZPStTc9jwySW']");
	
	
	public void SignIn (){
		
		
		if(isDisplayed(registerIdentifier)) {
			WaitForLoad();
			click(registerIdentifier);
			WaitForLoad();
			type("al9964472@gmail.com",userlocator);
			click(continueBtn);
			WaitForLoad();
			type("al9964472$%&",passwordLocator);
			click(signInBtn);
			if(isDisplayed(promotionBtn)) {
				WaitForLoad();
				click(promotionBtn);
				WaitForLoad();
				click(loBtn);
				WaitForLoad();

				for(int i = 1;i<=60;i++) {//For Implementation
					
					WaitForLoad();
					String nameProduct = ("(//div[@class='DealContent-module__truncate_sWbxETx42ZPStTc9jwySW'])"+"["+i+"]");
					By name = By.xpath(nameProduct);
					WebElement finalname = objDriver.findElement(name);
					String list = finalname.getAttribute("innerText");
					System.out.println(i+"-"+list);
					
					
				}
	
				
			} else {
			    System.out.print("An error occurred 1");	
			}
			
		}else {
			System.out.println("An error occurred 2");
		}
		

    }
    

		
		
		
}


