package exercise2;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;

public class base {//Class Constructor

	
	public static WebElement findElement(By locator) {//Wrapper of a Selenium Method
		return ClsBrowser.objDriver.findElement(locator);
		
	}
	
	public static List<WebElement> findElements(By locator){//Change to static
		return (List<WebElement>) ClsBrowser.objDriver.findElement(locator);
	}
	
	public String getText(WebElement element) {
		return element.getText();
	}
	
	public static String getText(By locator) {
		return ClsBrowser.objDriver.findElement(locator).getText();
	}
	
	public static void type(String inputText, By locator) {
		ClsBrowser.objDriver.findElement(locator).sendKeys(inputText);
	}
	
	public static Boolean isDisplayed(By locator) {
		
		try {
			
			return ClsBrowser.objDriver.findElement(locator).isDisplayed();
		}
		catch(org.openqa.selenium.NoSuchElementException e){
			return false;
		}
	}
	public void visit(String url ) {
		ClsBrowser.objDriver.get(url);
	}
	
	public static void click(By locator) {
		ClsBrowser.objDriver.findElement(locator).click();
	}
	
	
	public static void WaitForLoad() {
        ExpectedCondition<Boolean> pageLoadCondition = new
                ExpectedCondition<Boolean>() {
                    public Boolean apply(WebDriver driver) {
                        return ((JavascriptExecutor)driver).executeScript("return document.readyState").equals("complete");
                    }
                };
        WebDriverWait wait = new WebDriverWait(ClsBrowser.objDriver, 30);
        wait.until(pageLoadCondition);
    }
	
	

}